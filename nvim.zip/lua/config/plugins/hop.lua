return {
	{
		"phaazon/hop.nvim",
		lazy = true,
	},
}
